<?php
/**
 *@package LightQuery Container
 *@author Amadi Ifeanyi <amadiify.com>
**/
trait LightQuery{ use \Lightroom\Database\LightQuery; }
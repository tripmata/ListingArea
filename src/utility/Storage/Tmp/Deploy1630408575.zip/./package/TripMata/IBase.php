<?php

    Interface IBase
    {
        public function ToString();

        public  function ToInt();

        public  function ToBool();
    }
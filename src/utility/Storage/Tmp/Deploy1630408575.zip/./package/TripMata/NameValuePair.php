<?php

    class NameValuePair
    {
        public $Name = "";
        public $Value = "";
    }
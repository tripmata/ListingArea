<?php
// Assist manager for packages
return [

    // scaffolding 
    'scaffold' => [
        'path'      => constant('PATH_TO_CONSOLE') . '/Helper/Scaffolding/',
        'assist'    => constant('PATH_TO_CONSOLE') . '/Helper/Scaffold.php'
    ]

];
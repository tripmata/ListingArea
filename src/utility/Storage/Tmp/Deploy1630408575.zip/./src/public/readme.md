# Public
This directory contains public resources such as JavaScripts, CSS, and Images. Moorexa asset manager allows grouping of static images, CSS, JavaScripts in this directory for controllers.

Please visit the documentation for more information.
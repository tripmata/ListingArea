<?php

use Lightroom\Packager\Moorexa\Router as Route;

/*
 ***************************
 * 
 * @ Route
 * info: Add your GET, POST, DELETE, PUT request handlers here. 
*/
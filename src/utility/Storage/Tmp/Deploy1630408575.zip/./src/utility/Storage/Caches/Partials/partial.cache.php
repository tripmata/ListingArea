<?php
return array (
  '4759deea91e5ffde2d776f2797a3388e_meta-tags.html' => '33795dfa0f647d8e88a1721b5b970310',
);
?>
# Database Queries
This traits is an extenstion of the query builder.
<?php
namespace Lightroom\Exceptions;

use Exception;

/**
 * @package package manager exception
 * @author Amadi Ifeanyi <amadiify.com>
 */
class PackageManagerException extends Exception
{
    
}
<?php
namespace Lightroom\Exceptions;

use Exception;

/**
 * @package Payload Exceptions
 * @author fregatelab <fregatelab.com<
 */
class PayloadException extends Exception
{
    /**
     * @method PayloadException __construct
     * @param string $className
     */
    public function __construct(string $className)
    {
        
    }
}